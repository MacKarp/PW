﻿using UnityEngine;

namespace Assets.Script
{
    public class s1 : MonoBehaviour
    {
        // Start is called before the first frame update
        void Start()
        {
            GameObject[] doUsuniecia = GameObject.FindGameObjectsWithTag("Kula");
            foreach (var VARIABLE in doUsuniecia)
            {
                Destroy(VARIABLE);
            }
        }

        // Update is called once per frame
        void Update()
        {
        
        }
    }
}
