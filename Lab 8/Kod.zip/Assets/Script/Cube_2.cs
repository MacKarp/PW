﻿using UnityEngine;

namespace Assets.Script
{
    public class Cube_2 : MonoBehaviour
    {

        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {
            transform.rotation = Quaternion.Euler(0, Time.timeSinceLevelLoad * 60f, 0);
        }
    }
}
